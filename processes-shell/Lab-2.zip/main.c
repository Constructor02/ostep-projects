#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  printf("- - - Start - - -\n \n");

	if(argc > 2){
		printf("Too many arguments\n");
		goto end;
	}

	int lines = 1;

	char filename[] = "batch.txt";
	char line[30];

	if(argc == 2){
		FILE *fp = fopen(filename, "r");
		if (fp == NULL){
			printf("Could not open file %s.\n",filename);
		}else{
			while (fscanf(fp, "%[^\n]%*c", line) != EOF){
				printf("line%d: %s\n", lines, line);
				lines++;
			}
		}
		goto end;
	}

	char *str;
  size_t limit = 20;
	int size = 0;

	str = (char *)malloc(limit * sizeof(char));	

	while(1){
		printf("wish> ");
		size = getline(&str,&limit,stdin);
		if(strcmp(str, "exit\n") == 0){
			break;
		}
		printf("line%d: %s", lines, str);
		lines++;
	}

	end:
	printf("\n- - - End - - -\n");
  return 0;
}